
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Login Here</title>
</head>

<body>
     <h1>Cars - CPSC 2030</h1>
     
     <table class="table">
        <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Make</th>
              <th scope="col">Model</th>
              <th scope="col">Year</th>
              <th scope="col">Mileage</th>
    
            </tr>
        </thead>
        
<form action="" method="post">
    <input  class="btn btn-outline-secondary" type="text" name="username" placeholder="Enter your username" required>
    <input  class="btn btn-outline-secondary" type="password" name="password" placeholder="Enter your password" required>
    <button name ="submit" class="btn btn-primary btn-lg" type="submit">Login</button>
</form>
</body>

<?php
    session_start();
    
    $link = mysqli_connect( 'localhost', 'root', 'himanshu' );
    mysqli_select_db( $link, 'Demo' );
            
    $results = mysqli_query( $link, 'SELECT * FROM Cars' );
    // process $results
        while( $record = mysqli_fetch_assoc( $results) ) {
          $id = $record['ID'];
          $make = $record['Make'];
          $model = $record['Model'];
          $year = $record['Year'];
          $mileage = $record['Mileage'];
         
          print "<tr> <td>$id</td> <td>$make</td> <td>$model</td> <td>$year</td> <td>$mileage</td> </tr>";   

    }
    
    if(isset($_POST['submit'])){
        $user=$_POST["username"];
        $pass = $_POST["password"];

        if($user == "hi" && $pass =="hi"){
            $_SESSION['use'] = true;
            header("Location: index.php");
        }
        
        else{
            $_SESSION['use'] = false;
            echo "invalid password";
        }    
        
    }

    
?>

</html>