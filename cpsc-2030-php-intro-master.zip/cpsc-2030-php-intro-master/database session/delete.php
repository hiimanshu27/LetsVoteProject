<?php
   $i = $_POST['id'];

   $link = mysqli_connect( 'localhost', 'root', 'himanshu' );
   mysqli_select_db( $link, 'Demo' );
   
   $sql = "DELETE FROM Cars WHERE ID = $i"; 

   mysqli_query($link,$sql);
   
   mysqli_close($link);
   header("Location: index.php");
?>