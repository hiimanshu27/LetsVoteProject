<!DOCTYPE html>
<html>
    <body>

 <?php 
 
    echo "First Name    ".$_POST["name"]."<br>";
    echo "Last Name ".$_POST["lastName"]."<br>";
    echo "Email Address ".$_POST["email"]."<br>";
    echo "Address 1 ".$_POST["add"]."<br>";
    echo "Address 2 ".$_POST["add2"]."<br>";
    echo "Country   ".$_POST["country"]."<br>";
    echo "Provience/Teritory    ".$_POST["state"]."<br>";        
    echo "Postal Code   ".$_POST["code"]."<br>";
    
    if(isset($_POST["gift"])){
        echo "Gift card is selected <br>";
    }
    
    $d = $_POST["dilvery"];
    echo "Dilvery Method ".$d;
  
    echo "Name on card    ".$_POST["ccname"]."<br>";
    echo "Credit Card number    ".$_POST["ccnumber"]."<br>";
    echo "Expriation    ".$_POST["ccexp"]."<br>";
    echo "CVV    ".$_POST["ccvv"]."<br>";
    
    $a = $_POST["state"];
    if($a == "British Columbia")
    $q1 = $_POST["quantity1"];
    $q2 = $_POST["quantity2"];
    $q3 = $_POST["quantity3"];
    $totalCost = (12*$q1 + 8*$q2 + 5*$q3);
    
    if(isset($_POST["gift"])){
        $totalCost += 2;
    }
    
    echo "Total Cost    ".$totalCost."<br>";
    
    
    if($state == "Alberta" || $state == "British Columbia" || $state == "Manitoba" || $state == "Northwest Territories" || $state == "Quebec" || $state == "Yukon" ){
        $totalCost += $totalCost* 0.05;
    }
    else if($state == "New Brunswic" || $state == "Newfoundland and Labrado" || $state == "Nova Scotia"|| $state == "Prince Edward Island"){
        $totalCost += $totalCost*0.15;
    }
    else if($state == "Saskatchewan"){
        $totalCost += $totalCost*0.06;
    }
    else{
        $totalCost += $totalCost*0.13;
    }
      
    echo "Total Cost + Tax  ".$totalCost."<br>";
      
    if($totalCost > 750){
      echo "Credit card declined";
    }
    else{
        echo "Credit Card accepted";
    }
    
?>


</body>
</html>  